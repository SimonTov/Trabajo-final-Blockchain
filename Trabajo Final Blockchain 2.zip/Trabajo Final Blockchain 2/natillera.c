/*
 * natillera.c -- Natillera descentralizada (ahorro + prestamos + participaciones)
 *
 * Este archivo es SOLO el contrato (sin printf ni main), para verificarlo:
 *
 *   bash verificar.sh          (o:  frama-c -wp -wp-rte -wp-prover z3 natillera.c)
 *
 * La simulacion con numeros esta en simulacion.c (se compila con gcc).
 *
 * IDEA GENERAL
 *   - Los ahorradores depositan tokens y reciben PARTICIPACIONES (shares).
 *   - El fondo presta a prestatarios, que pagan capital + interes.
 *   - Interes: 10 % a la reserva, 90 % a los ahorradores.
 *   - Mora: la reserva absorbe primero; lo que falte lo pierden los ahorradores.
 *   - Sin colateral (decision de diseno: es una simulacion).
 *
 * CONTABILIDAD
 *     ACTIVOS = liquidez + prestado      PASIVOS = depositos + reserva
 *     INVARIANTE: ACTIVOS == PASIVOS
 *
 * PARTICIPACIONES (como se reparte en proporcion)
 *   - "depositos" es el valor total de todos los ahorradores.
 *   - Cada ahorrador tiene un numero de shares. Su valor es:
 *         valor = shares * depositos / total_shares
 *   - Interes y perdidas cambian "depositos" pero NO los shares: asi cada
 *     ahorrador gana o pierde automaticamente en proporcion a sus shares.
 *   - Un deposito nuevo compra shares al precio actual:
 *         shares_nuevas = monto * total_shares / depositos
 *     Por eso, al entrar mas gente, el PORCENTAJE de cada uno (sus shares sobre
 *     total_shares) baja, aunque su numero de shares no cambie.
 *
 * Todo es entero (en una blockchain no hay decimales) y se acota por 10^9 para
 * que los productos (shares * depositos) quepan en 64 bits sin desbordarse.
 */
 
#define LIMITE 1000000000LL   /* 10^9. En ACSL se escribe el literal. */
 
typedef struct {
    long long liquidez;      /* tokens disponibles en el contrato (no prestados) */
    long long prestado;      /* capital prestado que aun no ha vuelto            */
    long long depositos;     /* valor total que se le debe a los ahorradores     */
    long long reserva;       /* fondo de reserva                                 */
    long long total_shares;  /* participaciones emitidas en total                */
} Pool;
 
typedef struct {
    long long shares;        /* participaciones de ESTE ahorrador                */
} Ahorrador;
 
typedef struct {
    long long capital;       /* monto prestado                                   */
    long long interes;       /* interes fijado al crear el prestamo              */
    int       activo;        /* 1 = pendiente de pago, 0 = cerrado               */
} Prestamo;
 
/* ---------------------------------------------------------------------- */
/* Invariantes y funciones logicas                                         */
/* ---------------------------------------------------------------------- */
/*@
  predicate inv(Pool *p) =
       0 <= p->liquidez && 0 <= p->prestado
    && 0 <= p->depositos && 0 <= p->reserva
    && 0 <= p->total_shares <= 1000000000
    && p->liquidez + p->prestado == p->depositos + p->reserva
    && p->depositos + p->reserva <= 1000000000;
 
  predicate ahorrador_ok(Pool *p, Ahorrador *a) =
    0 <= a->shares <= p->total_shares;
 
  predicate prestamo_ok(Pool *p, Prestamo *l) =
       0 <= l->capital && 0 <= l->interes
    && (l->activo == 0 || l->activo == 1)
    && (l->activo == 1 ==> l->capital <= p->prestado);
 
  predicate deposito_valido(Pool *p, integer monto) =
    monto > 0 && monto <= 1000000000 - (p->depositos + p->reserva);
 
  predicate pool_liquidado(Pool *p) =
    p->total_shares > 0 && p->depositos == 0;
 
  // shares que se reciben al depositar "monto"
  logic integer nuevas_de(integer monto, integer dep, integer tot) =
    tot == 0 ? monto : (monto * tot) / dep;
 
  // valor en tokens de "s" shares
  logic integer valor_de(integer s, integer dep, integer tot) =
    (s * dep) / tot;
 
  // la division entera redondea hacia abajo
  lemma redondeo_abajo: \forall integer a, b;
    0 <= a && 0 < b ==> (a / b) * b <= a;
*/
 
/*@
  // HECHOS DE ARITMETICA NO LINEAL (se asumen; Z3 no los deduce solo).
  // "prod" y "coc" son nombres opacos para el producto y el cociente: asi Z3
  // puede activar los hechos cuando aparecen en una meta.
  //   prod_acotado: si a, b estan en [0, 10^9], entonces 0 <= a*b <= 10^18
  //                 (y 10^18 cabe en 64 bits: no hay desbordamiento).
  //   coc_acotado : con s <= tot y dep >= 0, (s*dep)/tot esta en [0, dep].
  //                 A mano: s*dep <= tot*dep; dividiendo entre tot > 0 queda
  //                 (s*dep)/tot <= dep; y s*dep >= 0 da cociente >= 0.
  axiomatic AritmeticaNoLineal {
    logic integer prod(integer a, integer b);
    logic integer coc(integer s, integer dep, integer tot);
 
    axiom prod_def: \forall integer a, b; prod(a, b) == a * b;
 
    axiom prod_acotado: \forall integer a, b;
      0 <= a <= 1000000000 && 0 <= b <= 1000000000 ==>
      0 <= prod(a, b) <= 1000000000000000000;
 
    axiom coc_def: \forall integer s, dep, tot;
      0 < tot ==> coc(s, dep, tot) == (s * dep) / tot;
 
    axiom coc_acotado: \forall integer s, dep, tot;
      0 <= s <= tot && 0 < tot && 0 <= dep ==>
      0 <= coc(s, dep, tot) <= dep;
  }
*/
 
/* ---------------------------------------------------------------------- */
/* depositar: un ahorrador mete tokens y recibe shares                     */
/*   1 = monto invalido o excede el limite                                 */
/*   3 = el fondo quedo en cero (hay shares pero valen 0): no se acepta    */
/*   4 = el monto es tan pequeno que no compra ni una share                */
/* ---------------------------------------------------------------------- */
/*@
  requires \valid(p) && \valid(a) && \separated(p, a);
  requires inv(p) && ahorrador_ok(p, a);
  assigns p->liquidez, p->depositos, p->total_shares, a->shares;
  ensures inv(p) && ahorrador_ok(p, a);
 
  behavior monto_invalido:
    assumes !deposito_valido(p, monto);
    assigns \nothing;
    ensures \result == 1;
 
  behavior fondo_liquidado:
    assumes deposito_valido(p, monto) && pool_liquidado(p);
    assigns \nothing;
    ensures \result == 3;
 
  behavior sin_shares:
    assumes deposito_valido(p, monto) && !pool_liquidado(p)
         && (nuevas_de(monto, p->depositos, p->total_shares) <= 0
             || nuevas_de(monto, p->depositos, p->total_shares)
                  > 1000000000 - p->total_shares);
    assigns \nothing;
    ensures \result == 4;
 
  behavior ok:
    assumes deposito_valido(p, monto) && !pool_liquidado(p)
         && 0 < nuevas_de(monto, p->depositos, p->total_shares)
         && nuevas_de(monto, p->depositos, p->total_shares)
              <= 1000000000 - p->total_shares;
    ensures p->liquidez  == \old(p->liquidez)  + monto;
    ensures p->depositos == \old(p->depositos) + monto;
    ensures p->total_shares == \old(p->total_shares)
      + nuevas_de(monto, \old(p->depositos), \old(p->total_shares));
    ensures a->shares == \old(a->shares)
      + nuevas_de(monto, \old(p->depositos), \old(p->total_shares));
    ensures \result == 0;
 
  complete behaviors;
  disjoint behaviors;
*/
int depositar(Pool *p, Ahorrador *a, long long monto) {
    if (monto <= 0 || monto > LIMITE - (p->depositos + p->reserva))
        return 1;
    if (p->total_shares > 0 && p->depositos == 0)
        return 3;
    long long nuevas = (p->total_shares == 0)
                     ? monto
                     : (monto * p->total_shares) / p->depositos;
    if (nuevas <= 0 || nuevas > LIMITE - p->total_shares)
        return 4;
    p->liquidez     += monto;
    p->depositos    += monto;
    p->total_shares += nuevas;
    a->shares       += nuevas;
    return 0;
}
 
/* ---------------------------------------------------------------------- */
/* retirar: el ahorrador devuelve "s" shares y recibe su valor en tokens   */
/*   1 = cantidad invalida                                                 */
/*   2 = no tiene tantas shares                                            */
/*   3 = no hay liquidez suficiente (el resto esta prestado)               */
/* ---------------------------------------------------------------------- */
/*@
  requires \valid(p) && \valid(a) && \separated(p, a);
  requires inv(p) && ahorrador_ok(p, a);
  assigns p->liquidez, p->depositos, p->total_shares, a->shares;
  ensures inv(p) && ahorrador_ok(p, a);
 
  behavior invalido:
    assumes s <= 0;
    assigns \nothing;
    ensures \result == 1;
 
  behavior sin_shares:
    assumes s > 0 && s > a->shares;
    assigns \nothing;
    ensures \result == 2;
 
  behavior sin_liquidez:
    assumes s > 0 && s <= a->shares
         && valor_de(s, p->depositos, p->total_shares) > p->liquidez;
    assigns \nothing;
    ensures \result == 3;
 
  behavior ok:
    assumes s > 0 && s <= a->shares
         && valor_de(s, p->depositos, p->total_shares) <= p->liquidez;
    ensures p->liquidez  == \old(p->liquidez)
      - valor_de(s, \old(p->depositos), \old(p->total_shares));
    ensures p->depositos == \old(p->depositos)
      - valor_de(s, \old(p->depositos), \old(p->total_shares));
    ensures p->total_shares == \old(p->total_shares) - s;
    ensures a->shares == \old(a->shares) - s;
    // el redondeo favorece al fondo: nadie recibe mas de lo que vale
    ensures valor_de(s, \old(p->depositos), \old(p->total_shares))
              * \old(p->total_shares) <= s * \old(p->depositos);
    ensures \result == 0;
 
  complete behaviors;
  disjoint behaviors;
*/
int retirar(Pool *p, Ahorrador *a, long long s) {
    if (s <= 0)
        return 1;
    if (s > a->shares)
        return 2;
    // Pistas para el probador (no cambian el comportamiento):
    //@ assert 0 <= prod(s, p->depositos) <= 1000000000000000000;
    //@ assert s * p->depositos == prod(s, p->depositos);
    long long valor = (s * p->depositos) / p->total_shares;
    //@ assert valor == coc(s, p->depositos, p->total_shares);
    //@ assert 0 <= valor <= p->depositos;
    if (valor > p->liquidez)
        return 3;
    p->liquidez     -= valor;
    p->depositos    -= valor;
    p->total_shares -= s;
    a->shares       -= s;
    return 0;
}
 
/* ---------------------------------------------------------------------- */
/* prestar: el fondo presta a un prestatario                               */
/*   - Siempre debe quedar >= 10 % de los activos como liquidez.           */
/*   - Tasa segun utilizacion (prestado / activos):                        */
/*        <= 50 %  -> 4 %  (capital/25)                                    */
/*        <= 80 %  -> 5 %  (capital/20)                                    */
/*        >  80 %  -> 10 % (capital/10)                                    */
/* ---------------------------------------------------------------------- */
/*@
  requires \valid(p) && \valid(l) && \separated(p, l);
  requires inv(p) && prestamo_ok(p, l);
  assigns p->liquidez, p->prestado, l->capital, l->interes, l->activo;
  ensures inv(p) && prestamo_ok(p, l);
 
  behavior rechazado:
    assumes l->activo == 1 || monto <= 0
         || monto > p->liquidez
         || (p->liquidez - monto) * 10 < p->liquidez + p->prestado;
    assigns \nothing;
    ensures \result == 1;
 
  behavior ok:
    assumes l->activo == 0 && monto > 0 && monto <= p->liquidez
         && (p->liquidez - monto) * 10 >= p->liquidez + p->prestado;
    ensures p->liquidez == \old(p->liquidez) - monto;
    ensures p->prestado == \old(p->prestado) + monto;
    ensures l->capital == monto && l->activo == 1;
    ensures 0 <= l->interes <= monto;
    // colchon de liquidez del 10 %
    ensures p->liquidez * 10 >= p->liquidez + p->prestado;
    ensures \result == 0;
 
  complete behaviors;
  disjoint behaviors;
*/
int prestar(Pool *p, Prestamo *l, long long monto) {
    if (l->activo == 1 || monto <= 0 || monto > p->liquidez)
        return 1;
    if ((p->liquidez - monto) * 10 < p->liquidez + p->prestado)
        return 1;
 
    long long interes;
    if (p->prestado * 2 <= p->liquidez + p->prestado)
        interes = monto / 25;
    else if (p->prestado * 10 <= (p->liquidez + p->prestado) * 8)
        interes = monto / 20;
    else
        interes = monto / 10;
 
    p->liquidez -= monto;
    p->prestado += monto;
    l->capital = monto;
    l->interes = interes;
    l->activo  = 1;
    return 0;
}
 
/* ---------------------------------------------------------------------- */
/* pagar: el prestatario devuelve capital + interes                        */
/*   10 % del interes -> reserva ; 90 % -> depositos (ahorradores)         */
/*   Los shares NO cambian: el valor de cada share sube solo.              */
/* ---------------------------------------------------------------------- */
/*@
  requires \valid(p) && \valid(l) && \separated(p, l);
  requires inv(p) && prestamo_ok(p, l);
  assigns p->liquidez, p->prestado, p->depositos, p->reserva, l->activo;
  ensures inv(p) && prestamo_ok(p, l);
 
  behavior rechazado:
    assumes l->activo == 0
         || l->interes > 1000000000 - (p->depositos + p->reserva);
    assigns \nothing;
    ensures \result == 1;
 
  behavior ok:
    assumes l->activo == 1
         && l->interes <= 1000000000 - (p->depositos + p->reserva);
    ensures p->prestado  == \old(p->prestado)  - l->capital;
    ensures p->liquidez  == \old(p->liquidez)  + l->capital + l->interes;
    ensures p->reserva   == \old(p->reserva)   + l->interes / 10;
    ensures p->depositos == \old(p->depositos) + (l->interes - l->interes / 10);
    ensures l->activo == 0;
    ensures \result == 0;
 
  complete behaviors;
  disjoint behaviors;
*/
int pagar(Pool *p, Prestamo *l) {
    if (l->activo == 0 || l->interes > LIMITE - (p->depositos + p->reserva))
        return 1;
    long long a_reserva = l->interes / 10;
    p->liquidez  += l->capital + l->interes;
    p->prestado  -= l->capital;
    p->reserva   += a_reserva;
    p->depositos += l->interes - a_reserva;
    l->activo = 0;
    return 0;
}
 
/* ---------------------------------------------------------------------- */
/* declarar_mora: el prestatario no pago; se reconoce la perdida           */
/*   1) la reserva absorbe lo que pueda                                    */
/*   2) lo que falte baja "depositos": cada share vale menos y la perdida  */
/*      se reparte entre ahorradores en proporcion a sus shares            */
/* ---------------------------------------------------------------------- */
/*@
  requires \valid(p) && \valid(l) && \separated(p, l);
  requires inv(p) && prestamo_ok(p, l);
  assigns p->prestado, p->reserva, p->depositos, l->activo;
  ensures inv(p) && prestamo_ok(p, l);
 
  behavior rechazado:
    assumes l->activo == 0;
    assigns \nothing;
    ensures \result == 1;
 
  behavior ok:
    assumes l->activo == 1;
    ensures p->prestado == \old(p->prestado) - l->capital;
    ensures l->activo == 0;
    ensures \result == 0;
    // la reserva se usa primero
    ensures l->capital <= \old(p->reserva) ==>
               p->depositos == \old(p->depositos)
            && p->reserva == \old(p->reserva) - l->capital;
    // si no alcanza, la reserva queda en 0 y el resto lo pagan los ahorradores
    ensures l->capital > \old(p->reserva) ==>
               p->reserva == 0
            && p->depositos == \old(p->depositos) - (l->capital - \old(p->reserva));
 
  complete behaviors;
  disjoint behaviors;
*/
int declarar_mora(Pool *p, Prestamo *l) {
    if (l->activo == 0)
        return 1;
    long long perdida  = l->capital;
    long long cubierto = (p->reserva < perdida) ? p->reserva : perdida;
    p->prestado  -= perdida;
    p->reserva   -= cubierto;
    p->depositos -= perdida - cubierto;
    l->activo = 0;
    return 0;
}
 