#!/bin/bash
# Verifica natillera.c con Frama-C (WP + Z3).
# Uso:  bash verificar.sh
#
# Frama-C imprime siempre dos avisos que no tienen relacion con el codigo:
#   "Skipped RTE guards: unaligned pointers ..."
#   "Skipped RTE guards: invalid function pointer calls ..."
# Significan que WP no soporta esos dos tipos de chequeo (el codigo no usa
# aritmetica de punteros ni punteros a funciones). Aqui se ocultan; el comando
# completo sin filtrar es:
#     frama-c -wp -wp-rte -wp-prover z3 -wp-timeout 30 natillera.c
cd "$(dirname "$0")" || exit 1
eval "$(opam env 2>/dev/null)"
frama-c -wp -wp-rte -wp-prover z3 -wp-timeout 30 natillera.c 2>&1 | grep -v 'Skipped RTE guards'
exit "${PIPESTATUS[0]}"
 