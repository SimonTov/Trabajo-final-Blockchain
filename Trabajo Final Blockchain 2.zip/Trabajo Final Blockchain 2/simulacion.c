/*
 * simulacion.c -- Simulacion con numeros de la natillera (NO se verifica).
 *
 * Compilar y ejecutar:
 *     gcc -Wall -Wextra simulacion.c -o simulacion && ./simulacion
 */
#include <stdio.h>
#include "natillera.c"

static long long valor(const Pool *p, long long s) {
    return p->total_shares == 0 ? 0 : (s * p->depositos) / p->total_shares;
}

static void estado(const char *t, const Pool *p, const Ahorrador *ana,
                   const Ahorrador *luis, const Ahorrador *carla) {
    printf("%s\n  liq=%lld prest=%lld dep=%lld res=%lld shares=%lld | activos=%lld pasivos=%lld\n",
           t, p->liquidez, p->prestado, p->depositos, p->reserva, p->total_shares,
           p->liquidez + p->prestado, p->depositos + p->reserva);
    if (p->total_shares > 0)
        printf("  Ana : %7lld shares (%5.1f %%) vale %lld\n"
               "  Luis: %7lld shares (%5.1f %%) vale %lld\n"
               "  Carla:%7lld shares (%5.1f %%) vale %lld\n",
               ana->shares,   100.0 * ana->shares   / p->total_shares, valor(p, ana->shares),
               luis->shares,  100.0 * luis->shares  / p->total_shares, valor(p, luis->shares),
               carla->shares, 100.0 * carla->shares / p->total_shares, valor(p, carla->shares));
}

int main(void) {
    Pool p = {0, 0, 0, 0, 0};
    Ahorrador ana = {0}, luis = {0}, carla = {0};
    Prestamo a = {0, 0, 0}, b = {0, 0, 0};

    depositar(&p, &ana, 600000);   depositar(&p, &luis, 300000);
    estado("Ana deposita 600.000 y Luis 300.000", &p, &ana, &luis, &carla);
    prestar(&p, &a, 500000);       prestar(&p, &b, 300000);
    estado("Se prestan 500.000 (A) y 300.000 (B)", &p, &ana, &luis, &carla);
    pagar(&p, &a);
    estado("A paga capital + interes (suben los depositos)", &p, &ana, &luis, &carla);
    declarar_mora(&p, &b);
    estado("B no paga: reserva primero, ahorradores el resto", &p, &ana, &luis, &carla);
    depositar(&p, &carla, 100000);
    estado("Carla deposita 100.000 DESPUES de la perdida", &p, &ana, &luis, &carla);
    printf("retirar 1.000.000 shares de Ana -> codigo %d (no los tiene)\n", retirar(&p, &ana, 1000000));
    printf("retirar 200.000 shares de Ana -> codigo %d\n", retirar(&p, &ana, 200000));
    estado("Despues del retiro de Ana", &p, &ana, &luis, &carla);
    return 0;
}
